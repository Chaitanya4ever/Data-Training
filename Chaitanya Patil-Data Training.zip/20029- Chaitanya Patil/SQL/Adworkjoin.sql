select * from Sales.SalesTerritory

SELECT COUNT(StateProvinceID), city
FROM Person.Address
GROUP BY city

select * from Person.CountryRegion


select distinct cr.Name as [Sales Country] 
from Person.CountryRegion as cr
inner join Sales.SalesTerritory as sr
on cr.CountryRegionCode = sr.CountryRegionCode

select * from Sales.SalesOrderHeader as soh
join sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
join sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
join Person.CountryRegion as cr on st.countryRegioncode=cr.CountryRegionCode

where (DATEPART(yyyy,soh.DueDate) in (@country))
group by DATEPART(yyyy,soh.DueDate),st.[group],cr.name
order by [calendar year] 


s
