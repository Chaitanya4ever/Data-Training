-- create 4 tables 
/*state(s_id,s_name) -- 2 records parent1
city(ct_id,ct_name,s_id) -- 4 records parent2 (child of parent1)
company(c_id,c_name,ct_id) -- 6 records parent3 (chile of parent2)
employee(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,c_id,ct_id) -- 10 records child (child of parent3, parent2) */
-- Apply suitable constraints

create table e_state (s_id int primary key, s_name varchar(20) not null)

insert into e_state ( s_id, s_name) values (101,'Maharashtra')
insert into e_state ( s_id, s_name) values (102,'Gujrat')
insert into e_state ( s_id, s_name) values (103,'Rajsthan')

create table e_city(c_id int primary key, c_name varchar(20) not null,s_id int not null foreign key references e_state(s_id)) 

insert into e_city(c_id, c_name, s_id) values (11,'Ahemdabad',102)
insert into e_city(c_id, c_name, s_id) values (12,'Surat',102)
insert into e_city(c_id, c_name, s_id) values (13,'Pune',101)
insert into e_city(c_id, c_name, s_id) values (14,'Mubai',101)
insert into e_city(c_id, c_name, s_id) values (15,'Jaypur',103)
insert into e_city(c_id, c_name, s_id) values (16,'Udaypur',103)

create table ecompany(cnid int primary key,c_name varchar (20),ct_id int not null foreign key references e_city(c_id)) -- 6 records parent3 (chile of parent2)


insert into ecompany(cnid,c_name,ct_id) values (111,'TCS', 11)
insert into ecompany(cnid,c_name,ct_id) values (222,'KCS', 12)
insert into ecompany(cnid,c_name,ct_id) values (333,'VisionAI', 13)
insert into ecompany(cnid,c_name,ct_id) values (444,'Medilife', 14)
insert into ecompany(cnid,c_name,ct_id) values (555,'MindAI', 15)
insert into ecompany(cnid,c_name,ct_id) values (666,'TATA', 16)
insert into ecompany(cnid,c_name,ct_id) values (777,'Microsoft', 13)
insert into ecompany(cnid,c_name,ct_id) values (888,'Tesla', 12)
insert into ecompany(cnid,c_name,ct_id) values (999,'TATA', 15)

create table empl(
e_id int primary key,
e_name varchar(20) not null,
e_dob date not null,
e_gender varchar(1) check(e_gender='M' or e_gender='F'),
e_email varchar(40) unique not null,
e_mobile numeric (10) check(len(e_mobile) = 10),
e_salary numeric(5) not null,
cnid int references ecompany(cnid),
c_id int references e_city(c_id))

select * from empl
select * from ecompany
select * from e_city

insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (1111,'Chaitanya','1999/08/31','M','chaitanya@kcs.com',9850398795,35000,333,14)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (4532,'Vishal','1998/06/14','M','vp@gmail.com',9850398796,44000,666,11)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (7543,'Bhavesh','1998/09/28','M','bhaves@gmail.com',9850398797,42000,222,12)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (8643,'Jayshri','1999/08/01','F','jayshri@gmail.com',9850398798,32000,888,15)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (4364,'Ridhhi','1998/08/12','F','ridhhi@gmail.com',9850398799,24000,999,14)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (3456,'Milind','1998/08/22','M','milind@gmail.com',9850398785,30000,555,11)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (6586,'VishalS','1998/04/30','M','vs@gmail.com',9850398775,24000,222,12)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (2434,'Mayuri','1999/03/03','F','mayuri@gmail.com',9850398765,51000,777,14)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (7654,'JD','1997/06/31','M','jd@gmail.com',9850398755,22000,444,15)


insert into empl(e_id,e_name,e_dob,e_gender,e_email,e_mobile,e_salary,cnid,c_id)
values (3221,'Ashwini','1997/08/23','F','ashwini@gmail.com',9850398745,40000,333,16)


--Get All Employee Details (use join).
select *
from empl e
join e_city ec
on e.c_id = ec.c_id 
join ecompany c
on e.cnid = c.cnid

--- display Oldest Employee Details.

-- display the details of employee its name start with 'r'.
-- display the details of employee its name second char is 'a'.
-- display the details of female employee who are born in 1995.
-- display the details of employee(both male and female) having maximum salary.
/*-- display all records but replace domain name (not change actual data)
	like aminesh@gmail.com to aminesh@ymail.com*/
	
-- Get only Second Highest Salary (without use CTE) (used sub_query,top and order by)
-- display the employee age (like 25 year old)
-- update the employee name first letter capital