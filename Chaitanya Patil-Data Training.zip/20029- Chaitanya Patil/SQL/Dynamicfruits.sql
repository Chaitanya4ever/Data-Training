 --	retrieve the average summary of all departments whose average salary is greater than the average salary in department id 2.


  select * from  (select d_id, avg(e_salary) as AVG_SALARY from emp
  group by d_id)employee where AVG_SALARY >(select distinct(AVG_SALARY) from emp where e_id = 6)

  select e_salary from emp where e_salary>(select e_salary from emp where e_id = 1)
  
  
  
  
create procedure fruits 
@fruit_name varchar(20),
@quentity int 
as
begin
declare @a int  = (select product_stock from product where product_name=@fruit_name)
if ((select product_stock from product  where product_name= @fruit_name) > @quentity ) 
begin 
	update product 
	set product_stock=product_stock-@quentity where product_name=@fruit_name
	insert into selling (s_name,s_stock) values (@fruit_name,@quentity) 
	select * from product
	select * from selling
end
else 
begin select 'Please enter Lower Quentity less then or equal  ' + cast(@a as varchar(20))
end
end





WITH CTE AS
(
	SELECT *,ROW_NUMBER() OVER (PARTITION BY id ,city_name ORDER BY id ,city_name) RN  FROM temp
)
DELETE FROM CTE WHERE RN<>1







select * from temp_2 where salary = (SELECT MAX(SALARY) FROM temp_2 WHERE SALARY < (SELECT MAX(SALARY) FROM temp_2))





declare  @start int = 1,@end int = 10, @num int = 1
while @start <= @end
begin
	print (Concat(@num , ' * ' , @start , ' = '  , @start*@num))
set @start += 1
if @start=11
begin 
if @num=11
	break
set @start = 1 
set @num= @num+1
end
end