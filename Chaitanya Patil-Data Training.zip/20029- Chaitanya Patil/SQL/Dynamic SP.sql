create table tablename
(
t_id int,
t_name varchar(30)
)


create proc sp_c
  @tablename nvarchar(10),
  @properties  nvarchar(100)
AS
begin
  create table @tablename
  (
    id  char(10)
  )
end


alter proc sp_ctbl
  @tablename nvarchar(10),
  @colname nvarchar(20),
  @coldatatype nvarchar(10),
  @colname2 nvarchar(20),
  @coldatatype2 nvarchar(10)
as
begin
	declare @fn varchar(10) = left(@tablename,1)

	declare @sql NVARCHAR(MAX)
	set @sql = 'create table ' + @tablename + '( '+@fn+'_'+@colname + ' ' + @coldatatype +', '+ @fn+'_'+@colname2+' '+@coldatatype2+'))'
	exec (@sql)
end


exec sp_ctbl 'stud', 'id', 'int','name','varchar(10)'

select * from stud





create table tb1(
id int,
name varchar(10)
)

create tblog(
id int,
loog nvarchar(max)
)

insert into @tblog values (@id, 'value inserted into' + @tb1 + 'at' date)