--scope aggregate function 

select DATEPART(YYYY,soh.duedate) as [Calendar Year],
st.[Group] as [Sales Territory Group],
cr.name as [Sales Territory country],
cr.name as [Sales Territory region],
sum(soh.TotalDue) as [Sales Amount],
p.Name as [productName] from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
inner join Person.CountryRegion as cr on st.CountryRegionCode=cr.CountryRegionCode
inner join Production.Product as p on pch.ProductID=p.ProductID
WHERE  (st.Name IN (@country)) AND (st.[Group] IN (@territory_name)) AND (DATEPART(yyyy, soh.DueDate) IN (@yearData))
group by DATEPART(yyyy,soh.DueDate),st.[Group],cr.Name,p.Name
order by [Calendar Year]


SELECT DATEPART(yyyy, soh.DueDate) AS [Calendar year], st.[Group] AS [sales territory group], cr.Name AS [Sales Territory Country], cr.Name AS [Sales Territory Region]
FROM     Sales.SalesOrderHeader AS soh INNER JOIN
                  Sales.SalesTerritory AS st ON soh.TerritoryID = st.TerritoryID INNER JOIN
                  Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID INNER JOIN
                  Production.ProductCostHistory AS pch ON sod.ProductID = pch.ProductID INNER JOIN
                  Person.CountryRegion AS cr ON st.CountryRegionCode = cr.CountryRegionCode
WHERE  (st.Name IN (@country)) AND (st.[Group] IN (@territory_name)) AND (DATEPART(yyyy, soh.DueDate) IN (@yearData))

