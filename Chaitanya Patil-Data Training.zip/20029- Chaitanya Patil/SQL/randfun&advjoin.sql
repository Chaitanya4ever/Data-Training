---	List all employees details with dob in form of �Friday,23 June,1995� for all employees. (use suitable date-time function)

select (datename(dw,ShipDate)+' , '
		+cast ((datepart(day,ShipDate))as varchar)+datename(month,ShipDate)+' , '
		+cast ((datepart(year,ShipDate))as varchar)) as NEW_DATE,* 
		from [Sales].[SalesOrderHeader]


--	List all employees details whose birth is in the month of 'august'. (like, where dob = 'august', use suitable date-time function)

select * from sales.SalesOrderHeader where datepart(month,ShipDate)=8

select duedate from sales.SalesOrderHeader where datename(month,ShipDate)='august'

print floor(rand())
print(convert(bit, 2*rand()))
select round(rand(),0) 
select convert(bit, round(1*rand(),0))

print(round(rand(),0))



select DATEPART(yyyy,soh.duedate) as [YEAR] ,SubTotal,TotalDue,SalesLastYear,[st].[group],cr.name as CITY_NAME

from sales.salesorderheader as soh
inner join sales.SalesTerritory as st on soh.territoryid=st.TerritoryID
inner join sales.salesorderdetail as sod on soh.salesorderid = sod.SalesOrderDetailID
inner join production.ProductCostHistory as pch on sod.ProductID= pch.ProductID
inner join Person.CountryRegion as cr on st.CountryRegionCode= cr.CountryRegionCode
where st.name in (@CITY_OF_COUNTRY) and [st].[group] in (@COUNTRY_GROUP) and DATEPART(yyyy,soh.duedate) in (@YEAR)




select cr.name [Sales Territory Country],st.[Group]
from person.CountryRegion as cr
inner join Sales.SalesTerritory as st
on cr.CountryRegionCode=st.CountryRegionCode
where st.[Group] in ('europe','pacific','North America')



  