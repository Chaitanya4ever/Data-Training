--ssrs country double parameter

select * from Sales.SalesOrderHeader
select * from sales.SalesTerritory
select * from sales.SalesOrderDetail
select * from Production.ProductCostHistory
select * from Person.CountryRegion



select DATEPART(yyyy,soh.DueDate) as [Calendar year],st.[group] as [sales territory group],
cr.Name as [Sales Territory Country],cr.Name as [Sales Territory Region],sum(soh.TotalDue) as [Sales Amount]
from Sales.SalesOrderHeader as soh
join sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
join sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
join Person.CountryRegion as cr on st.countryRegioncode=cr.CountryRegionCode
where (DATEPART(yyyy,soh.DueDate) in (@yearData))
group by DATEPART(yyyy,soh.DueDate),st.[group],cr.name
order by [calendar year]

select distinct [group] from Sales.SalesTerritory
select distinct [name] from Sales.SalesTerritory  where [Group] in (@country)

select distinct year(DueDate) from Sales.SalesOrderHeader


select distinct pcs.Name
from Person.CountryRegion as pcs
join Sales.SalesTerritory as sst
on pcs.CountryRegionCode = sst.CountryRegionCode





select cr.Name,DATEPART(yyyy,soh.DueDate) as [Year],soh.SubTotal,soh.Freight,soh.TaxAmt from Sales.SalesOrderHeader as soh
join sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
join sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
join Person.CountryRegion as cr on st.countryRegioncode=cr.CountryRegionCode
where (st.Name in(@)) and (st.[Group] in(@Country)) and (DATEPART(yyyy,soh.DueDate) in(@YEAR))

