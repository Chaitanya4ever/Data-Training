if not exists (select top 1 1 from filelog where fpath = ?)
begin
	insert into filelog values(?)
end

select * from filelog

Truncate table filelog


select * from emp

update emp set e_salary = ?*0.1 where e_id =?