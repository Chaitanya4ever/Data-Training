--double Parameter

select * from emp

--emp dataset
SELECT e_id, e_name, e_salary, e_mobno, e_mail, e_dob, e_city, e_country, d_id, gender
FROM     emp
WHERE  (e_country IN (@country)) AND (e_city IN (@city))

--country dataset
select distinct e_country from emp   --Country

--City Dataset
SELECT DISTINCT e_city		--City
FROM     emp
WHERE  (e_city IN (@city))

--3parameter

select DATEPART(YYYY,soh.duedate) as [Calendar Year],
st.[Group] as [Sales Territory Group],
cr.name as [Sales Territory country],
cr.name as [Sales Territory region],
sum(soh.TotalDue) as [Sales Amount],
p.Name as [productName] from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
inner join Person.CountryRegion as cr on st.CountryRegionCode=cr.CountryRegionCode
inner join Production.Product as p on pch.ProductID=p.ProductID
WHERE  (st.Name IN (@country)) AND (st.[Group] IN (@territory_name)) AND (DATEPART(yyyy, soh.DueDate) IN (@yearData))
group by DATEPART(yyyy,soh.DueDate),st.[Group],cr.Name,p.Name
order by [Calendar Year]		--main

--Country Name
SELECT DISTINCT Name
FROM     Sales.SalesTerritory
WHERE  ([Group] IN (@territory_name))

--Territory
SELECT DISTINCT [Group]
FROM     Sales.SalesTerritory

--Year
SELECT DISTINCT YEAR(DueDate) AS Expr1
FROM     Sales.SalesOrderHeader



------------------------------------------------------------------------------------------------------------------------
--Grouping

select DATEPART(YYYY,soh.duedate) as [Calendar Year],
st.[Group] as [Sales Territory Group],
sum(soh.TotalDue) as [Sales Amount],pc.name as category from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
cross join Production.ProductCategory as pc
group by DATEPART(yyyy,soh.DueDate),st.[Group],pc.Name
order by [Calendar Year]


--ScopeAggre

SELECT DATEPART(YYYY, soh.DueDate) AS [Calendar Year], st.[Group] AS [Sales Territory Group], 
cr.Name AS [Sales Territory country], cr.Name AS [Sales Territory region], SUM(soh.TotalDue) AS [Sales Amount]
FROM     Sales.SalesOrderHeader AS soh 
INNER JOIN Sales.SalesTerritory AS st ON soh.TerritoryID = st.TerritoryID 
INNER JOIN Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID 
INNER JOIN Production.ProductCostHistory AS pch ON sod.ProductID = pch.ProductID 
INNER JOIN Person.CountryRegion AS cr ON st.CountryRegionCode = cr.CountryRegionCode
GROUP BY DATEPART(yyyy, soh.DueDate), st.[Group], cr.Name
ORDER BY [Calendar Year]
--