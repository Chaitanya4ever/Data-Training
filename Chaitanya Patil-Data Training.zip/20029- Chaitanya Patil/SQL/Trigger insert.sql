use [Chaitanya.Patil]

create table empinfo  
(  
eid INT Identity(1,1),  
ename Varchar(100),  
esal Decimal (10,2)  
)

insert into empinfo values ('jd',1000);  
insert into empinfo values ('viki',1200);  
insert into empinfo values ('Avi',1100);  
insert into empinfo values ('Ladu',1300);  
insert into empinfo values ('Mili',1400);
insert into empinfo values ('Dada',1600);

select * from empinfo

create table EmpAudit  
(  
eid int,  
ename varchar(100),  
esal decimal (10,2),  
Aauditaction varchar(100),  
imestamp datetime  
)

create trigger crtrig ON empinfo   
for insert  
as
declare @empid int;  
declare @empname varchar(100);  
declare @empsal decimal(10,2);  
declare @audit_action varchar(100);  
select @empid=i.eid from inserted i;   
select @empname=i.ename from inserted i;   
select @empsal=i.esal from inserted i;   
set @audit_action='Inserted Record -- After Insert Trigger.';  
  
insert into EmpAudit  
(eid,ename,esal,Aauditaction,imestamp)   
values(@empid,@empname,@empsal,@audit_action,getdate());


print 'Inserted.'  
go

insert into empinfo values ('Jayashri',1000);
insert into empinfo values ('Soham',1600);


select * from EmpAudit  
select * from empinfo
